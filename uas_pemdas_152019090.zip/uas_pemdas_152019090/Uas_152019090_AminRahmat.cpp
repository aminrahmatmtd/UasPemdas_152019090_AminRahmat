#include <iostream>
#include <string>
#include<math.h>
using namespace std;
float totalsigmaX;
float totalsigmaY; 
float pwrX; 
float powerY;
float totalsigmaXY;
float total;
float sigmaXY;
float kuadXtotal; 
float kuadYtotal; 
float r;
int main(){
	int jumlah, x[10], y[10];
	cout << "jumlah data: ";cin >> jumlah;	
	for (int i=0;i<jumlah;i++){
		cout << "Data "<<i+1<<". "<<endl;
		cout << "X: ";cin >> x[i];
		if (x==0){
		cout << "Masukan Bilangan Sama Dengan Atau Lebih Dari 0!!!!!"<<endl;
		}
		cout << "Y: ";cin >> y[i];
		if (y==0){
			cout << "Masukan Bilangan Sama Dengan Atau Lebih Dari 0!!!!!"<<endl;
		}
		totalsigmaX=totalsigmaX+x[i];
		totalsigmaY=totalsigmaY+y[i]; 
		sigmaXY=x[i]*y[i],2;
		pwrX=pow(x[i],2);
		kuadXtotal=kuadXtotal+pwrX;
		powerY=pow(y[i],2);
		kuadYtotal=kuadXtotal+powerY;
		cout << "Total Sigma XY: " << sigmaXY << endl;
		total = total+sigmaXY;
	}
	totalsigmaXY=totalsigmaX+totalsigmaY;
	cout << "Sigma X: " << totalsigmaX <<	endl;
	cout << "Sigma Y: " << totalsigmaY <<	endl;
	cout << "Sigma X+Y: "<< totalsigmaXY << endl;
	cout << "X kuadrat: " << pwrX << endl;
	cout << "Total sigma X*Y: "<< total << endl;
	r= (total-totalsigmaXY)/sqrt(kuadXtotal)-pow(totalsigmaX,2)*sqrt(kuadYtotal)-pow(totalsigmaY,2);
	cout << "niali korelasi r: " << r << endl;
	cout << "Nilai koefisien determinasi :" << pow(r,2)*100/100 << endl;
	if (r>0){
		cout << "Hubungan Antara Variabel X dan Y adalah positif, dimana jika nilai X bertambah, maka nilai Y bertambah sebaliknya, dan juga sebaliknya" << endl;
	}else if (r<0){
		cout << "Hubungan Antara Variabel X dan Y adalah negatif, dimana jika X bertambah, maka nilai Y mengecil, dan juga sebaliknya" << endl;
	}else if (r=0){
		cout << "Tidak ada hubungan antara Variable X dan Y" << endl;
	}
	}
		
float sigmaXYs(int _X, int _Y){
	float hasil=0;
	hasil = _X*_Y;
	return hasil;
}